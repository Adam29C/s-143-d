import React from 'react'
import { ToastContainer } from 'react-toastify'

const Toast = () => {
  return (
    <div>
         <ToastContainer />
    </div>
  )
}

export default Toast