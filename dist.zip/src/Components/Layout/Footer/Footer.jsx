import React from "react";

const Footer = () => {
  return (
    <div>

    <div classname="footer">
      {/* <div classname="copyright">
        <p>
          Copyright © Designed &amp; Developed by
        </p>
      </div> */}
    </div>
  </div>
  
  );
};

export default Footer;
