import React from "react";

const Logo_png = () => {
  return (
    <div>
      <div className="d-flex my-4 justify-content-center ">
        <img
         id="company-logo"
       
          alt="logo"
          className="w-50"
        />
      </div>
    </div>
  );
};

export default Logo_png;
