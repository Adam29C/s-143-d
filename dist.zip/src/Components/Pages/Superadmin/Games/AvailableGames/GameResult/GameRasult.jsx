import React from "react";
// import ExamplePage from "./SplitCard";
import ExamplePage from "./SplitCard";

const GameRasult = () => {
  return (
    <div>
      <ExamplePage />
    </div>
  );
};

export default GameRasult;
